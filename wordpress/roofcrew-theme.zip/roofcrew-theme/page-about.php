<?php
/* About page. Generated from the v2 design by tools/build_wp_theme.py: edit the generator, not this file. */
rc_meta( "About The Roof Crew | Family-Owned Auckland Roofers", "The Roof Crew is a family-owned Auckland roofing company. Mike has 30+ years in construction and has been roofing Auckland homes since 2014. Find out how we work." );
get_header(); ?>

<section class="hero page-hero"><div class="hero-bg" style="background-image:url('<?php echo rc_theme_uri(); ?>/assets/img/about-hero-crew.jpg')"></div>
<div class="wrap"><div><span class="eyebrow">About us</span><h1>Family-owned, with Mike on every job</h1>
<p class="lede">The Roof Crew is a family-owned Auckland roofing company. Mike has 30+ years in construction and has been roofing Auckland homes since 2014. When you call us, you get Mike, and he personally runs your job alongside his trusted team of experienced roofers.</p>
<div class="hero-actions"><a class="btn btn-primary" href="<?php echo rc_url('quote'); ?>">Get my free quote →</a></div></div></div></section>
<section><div class="wrap split">
  <div class="prose"><span class="eyebrow">Our story</span><h2 style="margin-bottom:18px">Why we do it this way</h2>
    <p>We know that sinking feeling when a stain appears on the ceiling. You start wondering how bad it is, how much it'll cost, and who you can trust to tell you the truth. We meet people feeling exactly that every week.</p><p>So we keep it simple. Mike comes out, looks at the roof and tells you what it needs. If a repair will do, he'll say so. If it's time for a new roof, you'll get a fixed, itemised price and no pressure to go ahead.</p><p>In Mike's words: “I started The Roof Crew back in 2014, supplying and installing Metrotile roofing systems and long-run COLORSTEEL® roofing systems. I've always believed in providing good workmanship, honest advice and reliable service. We're a family-owned Auckland business, and I'm still personally involved in every job, working alongside a trusted team of experienced roofers to make sure the work is done properly and to a high standard.”</p></div>
  <div class="photo" style="min-height:400px"><img src="<?php echo rc_theme_uri(); ?>/assets/img/colorsteel-after.jpg" alt="A finished COLORSTEEL reroof on an Auckland home" loading="lazy"></div>
</div></section>
<section class="alt"><div class="wrap narrow"><span class="eyebrow">On site</span><h2 style="margin-bottom:22px">How we look after your home</h2>
  <div class="prose"><p>A roof job puts a crew on top of your house for days, so how we work matters. We set up scaffolding and edge protection, meet our health and safety obligations, and leave the site tidy at the end of each day. We take the old roof away and dispose of it responsibly.</p><p>Sometimes we find problems we couldn't see until the roof came off, especially on older villas. When that happens, we'll show you, explain the options and bring in a builder we trust if timber work is needed.</p></div>
</div></section>
<section><div class="wrap"><span class="eyebrow">Accreditations and warranty</span><h2 style="margin-bottom:32px">What's backed in writing</h2>
  <div class="grid-3"><div class="card"><div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg></div><h3>Workmanship</h3><p>Every job comes with a 5-year workmanship warranty (conditions apply).</p></div><div class="card"><div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V9l7-5 7 5v12"/><path d="M9 21v-6h6v6"/></svg></div><h3>Products</h3><p>The manufacturer's warranty covers the products on top of that.</p></div><div class="card"><div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg></div><h3>Insurance</h3><p>We're fully insured.</p></div><div class="card"><div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/></svg></div><h3>Gerard</h3><p>We're resellers and installers of Gerard products.</p></div><div class="card"><div class="icon"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg></div><h3>RANZ</h3><p>We're a member of RANZ, the Roofing Association of New Zealand.</p></div></div>
</div></section>
<section class="alt"><div class="wrap"><span class="eyebrow">Reviews</span><h2 style="margin-bottom:32px">Rated 4.7 stars on Google</h2><div class="reviews">
  <div class="card rating-card"><span class="g"><svg width="18" height="18" viewBox="0 0 48 48"><path fill="#4285F4" d="M45 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h11.8c-.5 2.7-2.1 5-4.4 6.6v5.5h7.1C42.6 36.8 45 31.2 45 24.5z"/><path fill="#34A853" d="M24 46c5.9 0 10.9-2 14.5-5.3l-7.1-5.5c-2 1.3-4.5 2.1-7.4 2.1-5.7 0-10.5-3.8-12.2-9H4.5v5.7C8.1 41.1 15.5 46 24 46z"/><path fill="#FBBC05" d="M11.8 28.3c-.4-1.3-.7-2.7-.7-4.3s.3-3 .7-4.3V14H4.5C3 17 2 20.4 2 24s1 7 2.5 10l7.3-5.7z"/><path fill="#EA4335" d="M24 10.7c3.2 0 6.1 1.1 8.4 3.3l6.3-6.3C34.9 4.2 29.9 2 24 2 15.5 2 8.1 6.9 4.5 14l7.3 5.7c1.7-5.2 6.5-9 12.2-9z"/></svg> Google reviews</span><b>4.7</b><div class="stars">★★★★★</div>
    <p style="font-size:15px;color:var(--gray-500)">Google rating</p><a class="link" href="https://www.google.com/search?q=The+Roof+Crew&kgmid=/g/11cn6bg8js#lrd=0x6d0d4b1657cb17fd:0x564d5993b3d86a34,1,,,," target="_blank" rel="noopener" style="display:inline-block;margin-top:12px">Read all reviews on Google →</a></div>
  <figure class="card review"><div class="stars">★★★★★</div><blockquote>We highly recommend The Roof Crew! Great communication, excellent service and very high-quality work produced. We are very satisfied with the results, and we would definitely contact them again in the future!</blockquote><cite>Tanyamai, Epsom</cite></figure><figure class="card review"><div class="stars">★★★★★</div><blockquote>I highly recommend The Roof Crew for your next roof project. Mike and the 3 guys that came to help me were very professional, on time and on promise. Mike's comms was clear and open - there were no surprises. The 3 guys that did the work were fantastic too! I am so impressed with the result - I would book The Roof Crew again in a heart-beat. Thanks guys!!</blockquote><cite>Sarah, Howick</cite></figure><figure class="card review"><div class="stars">★★★★★</div><blockquote>Mike and his team did a very professional job replacing my roof back in June, just before the rainy season. They did a great job of working around the weather and choosing a suitable dry spell between rainy days. The whole job went very smoothly. Highly recommended!</blockquote><cite>James, Māngere</cite></figure></div></div></section>
<section id="request"><div class="wrap closing">
  <div>
    <span class="eyebrow">Request a quote</span>
    <h2>Your roof, your real number.</h2>
    <p class="lede">Tell us a bit about your property and Mike will get back to you personally.</p>
    <ol class="steps">
      <li><span class="n">1</span><div><b>Send your details</b><span>Takes about a minute, or just call or text.</span></div></li>
      <li><span class="n">2</span><div><b>Mike gets in touch</b><span>We aim to respond within 3 hours and visit within the next working day.</span></div></li>
      <li><span class="n">3</span><div><b>A clear, itemised quote</b><span>Fixed, transparent and no pressure.</span></div></li>
    </ol>
    <div class="contact-box"><a href="tel:+6421903822"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/></svg> 021 903 822</a><a href="mailto:mike@theroofcrew.co.nz"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg> mike@theroofcrew.co.nz</a></div>
  </div>
  <div class="quote-card<?php echo rc_sent( 'get-quote' ) ? ' is-sent' : ''; ?>" id="get-quote">
  <h2>Get your free quote</h2><p class="sub">Free and no pressure.</p>
  <?php rc_form_open('get-quote'); ?>
    <div><label for="get-quote-name">Name</label><input id="get-quote-name" name="name" autocomplete="name" required></div>
    <div><label for="get-quote-phone">Phone</label><input id="get-quote-phone" name="phone" type="tel" autocomplete="tel" required></div>
    <div class="full"><label for="get-quote-email">Email</label><input id="get-quote-email" name="email" type="email" autocomplete="email"></div>
    <div class="full"><label for="get-quote-addr">Suburb or address</label><input id="get-quote-addr" name="address" autocomplete="street-address"></div>
    <div class="full"><label for="get-quote-need">What's going on with your roof?</label><select id="get-quote-need" name="need"><option selected>New roof (reroof)</option><option>Leaks keep coming back</option><option>Not sure, please check it</option><option>Roof repair</option><option>Spouting or downpipes</option><option>Inspection or report</option><option>New build roof</option><option>Commercial roofing</option></select></div>
    <div class="full"><label for="get-quote-msg">Anything else? (optional)</label><textarea id="get-quote-msg" name="message"></textarea></div>
    <div class="full"><button class="btn btn-primary btn-block" type="submit">Get my free quote →</button></div>
    <div class="full hp" aria-hidden="true"><label>Leave this empty<input name="website" tabindex="-1" autocomplete="off"></label></div>
    <p class="full fine">Mike will call you back personally. No sales pressure. <a href="<?php echo rc_url('privacy-policy'); ?>">Privacy policy</a></p>
  </form>
  <div class="form-done" tabindex="-1"><strong>Thanks<?php echo rc_sent_name(); ?>.</strong>Mike will be in touch to book your free site visit.</div>
</div>
</div></section>
<?php get_footer();
